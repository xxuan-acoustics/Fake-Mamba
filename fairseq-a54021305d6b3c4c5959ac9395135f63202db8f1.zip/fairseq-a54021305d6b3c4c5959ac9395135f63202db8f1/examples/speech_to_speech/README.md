# Speech to speech translation

## Direct speech-to-speech translation with discrete units
[https://arxiv.org/abs/2107.05604](https://arxiv.org/abs/2107.05604)
